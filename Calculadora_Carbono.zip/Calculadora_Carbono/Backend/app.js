var dotenv = require('dotenv');
dotenv.config();

var seq = require('./sequelize.js');

var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var path = require('path');
var flash = require('connect-flash');
var cors = require('cors');

var usersRouter = require('./routes/users');
var indexRouter = require('./routes/index');
var respostasRouter =  require ('./routes/respostas');
var perguntasRouter = require ('./routes/perguntas');
var opcao_perguntaRouter = require ('./routes/sugestions.js');
var pontuacaoRouter = require ('./routes/pontuacao.js');
var sugestionsRouter = require('./routes/sugestions.js');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'))
app.use(cookieParser()); // read cookies (needed for auth)
app.use(express.json()); // get information from html forms
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());

// Use the session middleware
 app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true   
})); 

app.use(flash()); // use connect-flash for flash messages stored in session
app.use('/',indexRouter);
app.use('/users',usersRouter);
app.use('/respostas',respostasRouter);
app.use('/perguntas',perguntasRouter);
app.use('/opcaoperguntas',opcao_perguntaRouter);
app.use('/pontuacaos',pontuacaoRouter);
app.use('/sugestions',sugestionsRouter)


module.exports = app;