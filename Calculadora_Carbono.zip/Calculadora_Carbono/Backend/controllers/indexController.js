const Users = require('../sequelize').User;
var jwt = require ('jsonwebtoken');

function generateAccessToken(email,password){
    var token = jwt.sign({email, password}, process.env.TOKEN_SECRET,
        {expiresIn:'18000s'});
    return token;
}

exports.signup = function (req,res,next){
    var email = req.body.email;
    var password = req.body.password;
    Users.findOne({
        where:{
            email: email
        }
        }).then(user=>{
            if(user  == null){
                Users.create ({'email':email, 'password': password})
                .then(user => {
                    var token = generateAccessToken(email,password);
                    console.log(token);
                    res.status(200).json({user,token});
                    
                })
            }else{
              res.Status(401).json({message:"Ese email esta en uso"})
            }
       
    })
}

exports.login = function (req,res,next){
    var email = req.body.email;
    var password = req.body.password;
    Users.findOne({
        where:{
            email: email
        }
        }).then(user=>{
            if(user  == null){
                req.flash ('loginMessage', 'No user found with that e-mail.');
                res.redirect('/login');
            }
            else if (user.password != password){
                req.flash('loginMessage','Oops! Wrong password.');
                res.redirect('/login');
            }else{
                const token = generateAccessToken(email,password);
                console.log(token);
                res.status(200).json({user,token});
            }
       
    }).catch (function (err){
        //handle error;
        req.flash('loginMessage', err);
        res.redirect('/login');
    })   
}