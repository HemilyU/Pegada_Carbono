const opcaopergunta = require ('../sequelize').opcao_pergunta
//getAll opção de perguntas
exports.getAllOpcao= (req,res,next) => {
    opcaopergunta.findAll().then(opcaopergunta =>{
        res.send(opcaopergunta);
    });
}


exports.postOpcaoByBody = (req, res, next) => {
    opcaopergunta.create(req.body).then(opcaopergunta =>{
        res.send("Opção de pergunta adicionada como ID: " + opcaopergunta.id);
    });
}

exports.deleteOpcaoById = (req, res, next) => {
    var id = req.params.id;
    opcaopergunta.destroy({
        where: {
            id: id
        }
    }).then(opcaopergunta => {
        if (opcaopergunta.affectedRows == 0) {
            res.send("ID NAO EXISTE");
        } else {
            res.send(opcaopergunta.affectedRows);
        }
    })
}


exports.updateOpcaoById = (req, res, next) => {
    var id = req.params.id;
    opcaopergunta.update(req.body,{
        where: {
            id: id
        }
    }).then(affectedRows => {
        if (affectedRows == 0) {
            res.send("Opção nao existe");
        } else {
            res.send(affectedRows);
        }
    })
}

exports.getOpcaoById = (req,res,next) => {
    var id = req.params.id;
    opcaopergunta.findByPk(id)
    .then(opcaopergunta => {
        if (opcaopergunta == undefined) {
            res.send("ID NAO EXISTE");
        } else {
            res.send(opcaopergunta);
        }
    })
}