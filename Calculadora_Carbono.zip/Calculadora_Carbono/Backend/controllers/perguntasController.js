const perguntas = require ('../sequelize').perguntas;

//getAll perguntas
exports.getAllPerguntas= (req,res,next) => {
    try {
        perguntas.findAll().then(perguntas =>{
            res.send(perguntas);
        });
    } catch (error) {
        res.status(500).end("Internal server error");
    }

  
}

//post de uma pergunta por ID
exports.postPerguntasByBody = (req, res, next) => {
    perguntas.create(req.body).then(perguntas =>{
        res.send("Pergunta adicionada com o ID: " + perguntas.id);
    });
}

//Delete pergunta por ID
exports.deletePerguntasById = (req, res, next) => {
    var id = req.params.id;
    perguntas.destroy({
        where: {
            id: id
        }
    }).then(perguntas => {
        if (perguntas.affectedRows == 0) {
            res.send("ID NAO EXISTE");
        } else {
            res.send("Pergunta apagado com o ID: "+id);
        }
    })
}

//endpoint para fazer update uma pergunta por ID
exports.updatePerguntasById = (req, res, next) => {
    var id = req.params.id;
    perguntas.update(req.body,{
        where: {
            id: id
        }
    }).then(affectedRows => {
        if (affectedRows == 0) {
            res.send("Pergunta não existe");
        } else {
            res.send("Pergunta atualizada com o ID: "+id);
        }
    })
}

//endpoint para obter uma pergunta por ID
exports.getPerguntasById = (req,res,next) => {
    var id = req.params.id;
    perguntas.findByPk(id)
    .then(perguntas => {
        if (perguntas == undefined) {
            res.send("ID NAO EXISTE");
        } else {
            res.send(perguntas);
        }
    })
}
