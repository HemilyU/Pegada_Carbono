const Pontuacao = require('../sequelize').pontuacao;

function calcularHuellaCarbono(respuestas) {
    const suma = respuestas.reduce((acc, respuesta) => acc + respuesta, 0);
    const huellaCarbono = suma * 0.1; // Factor de conversión arbitrario
  
    return huellaCarbono;
  }

exports.getAllPontuacao = (req, res, next) => {
  Pontuacao.findAll()
    .then(Pontuacao => {
      res.send(Pontuacao);
    })
    .catch(error => {
      console.error('Error al obtener todas las pontuações:', error);
      res.status(500).json({ error: 'Error al obtener todas las pontuações' });
    });
};

exports.postPontuacao = (req, res, next) => {
  const pontuacao_respostas = req.body.pontuacao_respostas; 
  const huellaCarbono = calcularHuellaCarbono(pontuacao_respostas);
  const huellaCarbonoString = huellaCarbono.toString();
  
  Pontuacao.create({ pontuacao_respostas: huellaCarbonoString })
    .then(pontuacao => {
      // Realizar el cálculo de la huella de carbono aquí utilizando las respuestas guardada

      // Devolver la huella de carbono como respuesta
      res.json({ huellaCarbono: huellaCarbonoString });
    })
    .catch(error => {
      console.error('Error al guardar las respuestas:', error);
      res.status(500).json({ error: 'Error al guardar las respuestas' });
    });
};

//Delete pontuacao por ID
exports.deletePontuacaoById = (req, res, next) => {
    var id = req.params.id;
    Pontuacao.destroy({
        where: {
            id: id
        }
    }).then(pontuacao => {
        if (pontuacao.affectedRows == 0) {
            res.send("ID NAO EXISTE");
        } else {
            res.send("Pontuação deleted com o ID: "+id);
        }
    })
}

//endpoint para fazer update uma pontuacao por ID
exports.updatePontuacaoById = (req, res, next) => {
    var id = req.params.id;
    Pontuacao.update(req.body,{
        where: {
            id: id
        }
    }).then(affectedRows => {
        if (affectedRows == 0) {
            res.send("ID não existe");
        } else {
            res.send(affectedRows);
        }
    })
}

//endpoint para obter uma pergunta por ID
exports.getPontuacaoById = (req,res,next) => {
    var id = req.params.id;
    Pontuacao.findByPk(id)
    .then(pontuacao => {
        if (pontuacao == undefined) {
            res.send("ID NAO EXISTE");
        } else {
            res.send(pontuacao);
        }
    })
}

