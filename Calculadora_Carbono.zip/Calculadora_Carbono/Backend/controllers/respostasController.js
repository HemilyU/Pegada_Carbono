const respostas = require ("../sequelize").respostas;

// obtem todas as respostas
exports.getAllRespostas = (req,res,next) => {
    respostas.findAll().then(respostas =>{
        res.send(respostas);
    });
}

exports.postRespostasByBody = (req, res, next) => {
    respostas.create(req.body).then(Answer =>{
        res.send("Resposta criada com o ID: " + respostas.id);
    });
}

//endpoint para apagar uma resposta por ID
exports.deleteRespostasById = (req, res, next) => {
    var id = req.params.id;
    respostas.destroy({
        where: {
            id: id
        }
    }).then(respostas => {
        if (respostas.affectedRows == 0) {
            res.send("ID NAO EXISTE");
        } else {
            res.send(respostas.affectedRows);
        }
    })
}

// update uma resposta por ID
exports.updateRespostasById = (req, res, next) => {
    var id = req.params.id;
    respostas.update(req.body,{
        where: {
            id: id
        }
    }).then(affectedRows => {
        if (affectedRows == 0) {
            res.send("Resposta não existe");
        } else {
            res.send(affectedRows);
        }
    })
}

// todos os resultados de um ID
exports.getRespostasById = (req, res, next) => {
    var id = req.params.id;
    respostas.findByPk(id)
    .then(respostas => {
      if (respostas == undefined) {
        res.send("ID NAO EXISTE");
      } else {
        res.send(respostas);
      }
    });
}