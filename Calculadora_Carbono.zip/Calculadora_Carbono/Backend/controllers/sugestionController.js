const Sugestion = require('../sequelize').sugestions;

exports.getAllSugestion = (req, res, next) => {
    Sugestion.findAll()
    .then(Sugestion => {
      res.status(200).json(Sugestion);
    })
    .catch(error => {
      res.status(500).json({ error: 'Error getting sugestions' });
    });
};

exports.createSugestion = (req, res, next) => {
  const { texto } = req.body;

  Sugestion.create({ texto })
    .then(createdSugestion => {
      res.status(201).json(createdSugestion);
    })
    .catch(error => {
      res.status(500).json({ error: 'Error creating sugestions' });
    });
};

exports.updateSugestion = (req, res, next) => {
  const SugestionId = req.params.id;
  const updatedData = req.body;

  Sugestion.findByPk(SugestionId)
    .then(Sugestion => {
      if (Sugestion) {
        return Sugestion.update(updatedData);
      } else {
        res.status(404).json({ error: 'Sugestion Not found' });
      }
    })
    .then(updatedSugestion => {
      res.status(200).json(updatedSugestion);
    })
    .catch(error => {
      res.status(500).json({ error: 'Failed to update Sugestion' });
    });
};

exports.deleteSugestion = (req, res, next) => {
  const SugestionId = req.params.id;

  Sugestion.findByPk(SugestionId)
    .then(Sugestion => {
      if (Sugestion) {
        Sugestion.destroy();
        res.send("Sugestion with id: "+SugestionId+" deleted")
      } else {
        res.status(404).json({ error: 'Sugestion Not found' });
      }
    })
    .then(() => {
      res.status(204).end();
    })
    .catch(error => {
      res.status(500).json({ error: 'Error deleting Sugestion' });
    });
};
