const respostas = require('../sequelize').Answer; //exportar todas as tabelas de sql
const perguntas = require('../sequelize').Question;
const User = require('../sequelize').User;

exports.getAllUsers = (req,res,next) => {
    User.findAll().then(users =>{
        res.send(users);
    });
}

exports.postUserByBody = (req, res, next) => {
    User.create(req.body).then(User =>{
        res.send("New User has been added with the ID: " + User.id);
    });
}

exports.deleteUserById = (req, res, next) => {
    var id = req.params.id;
    User.destroy({
        where: {
            id: id
        }
    }).then(User => {
        if (User.affectedRows == 0) {
            res.send("ID NAO EXISTE");
        } else {
            res.send("User deleted with id: "+id);
        }
    })
}

exports.updateUserById = (req, res, next) => {
    var id = req.params.id;
    User.update(req.body,{
        where: {
            id: id
        }
    }).then(affectedRows => {
        if (affectedRows == 0) {
            res.send("User nao existe");
        } else {
            res.send("User updated!");
        }
    })
}


exports.getUserById = (req,res,next) => {
    var id = req.params.id;
    User.findByPk(id)
    .then(User => {
        if (User == undefined) {
            res.send("ID NAO EXISTE");
        } else {
            res.send(User);
        }
    })
}

