const sequelize = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    return sequelize.define('opcaopergunta', {
        texto_opcao: {
            type: DataTypes.STRING,
        },
        valor_opcao: {
            type: DataTypes.INTEGER,
        }
    })
}