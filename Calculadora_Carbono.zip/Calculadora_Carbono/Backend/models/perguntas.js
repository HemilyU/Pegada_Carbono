const sequelize = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    return sequelize.define('pergunta', {
        texto_perguntas: {
            type: DataTypes.STRING,
        },
        opcao_pergunta: {
            type: DataTypes.STRING,
        }
    })
}