const sequelize = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    return sequelize.define('pontuacao', {
        pontuacao_respostas:{
            type: DataTypes.STRING,
            allowNull: true, // Permitir valores nulos para atualização
            defaultValue: null, // Valor padrão inicial como nulo
        }
    })
}