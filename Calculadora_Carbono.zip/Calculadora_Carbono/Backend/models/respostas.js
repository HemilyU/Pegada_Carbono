const sequelize = require("sequelize");

module.exports = (sequelize, DataTypes)=>{
    return sequelize.define('respostas',{
        opcao_resposta:{
            type: DataTypes.STRING,
        },
    })
}