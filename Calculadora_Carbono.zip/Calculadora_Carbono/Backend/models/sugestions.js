const sequelize = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    return sequelize.define('sugestions', {
        texto: {
            type: DataTypes.STRING,
        },
    })
}