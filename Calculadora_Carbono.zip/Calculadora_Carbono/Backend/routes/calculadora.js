function calcularHuellaCarbono(respuestas) {
    const suma = respuestas.reduce((acc, respuesta) => acc + respuesta, 0);
    const huellaCarbono = suma * 0.1; // Factor de conversión arbitrario
  
    return huellaCarbono;
  }
  
  module.exports = {
    calcularHuellaCarbono
  };