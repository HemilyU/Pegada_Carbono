var express = require('express');
var router = express.Router();
var jwt = require('jsonwebtoken');
var indexController = require ('../controllers/indexController');
/* GET home page. */
router.get('/', function(req, res) {
    res.render('index', { title: 'Express' });
});

router.post ('/login', indexController.login);
router.post ('/signup', indexController.signup);

function authenticateTokenFromSession(req,res,next){
    const token = req.session.token;
    if (token == null) return res.sendStatus(401);
    jwt.verify (token, process.env.TOKEN_SECRET, (err,user)=>{
        if (err)
        return req.sendStatus(403);
        //req.user = user;
        next();
    });
}


module.exports = router;
