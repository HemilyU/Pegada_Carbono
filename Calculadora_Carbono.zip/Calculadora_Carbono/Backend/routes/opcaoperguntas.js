var express = require('express');
var router = express.Router();
var opcao_perguntaRouter = require('../controllers/opcaoperguntasController.js'); //exportar os endpoints da pasta controllers

router.get('/', opcao_perguntaRouter.getAllOpcao);
router.post('/', opcao_perguntaRouter.postOpcaoByBody);
router.delete('/:id', opcao_perguntaRouter.deleteOpcaoById); //configurar a rota do endpoint
router.put('/:id', opcao_perguntaRouter.updateOpcaoById);
router.get('/:id', opcao_perguntaRouter.getOpcaoById);

module.exports = router;
