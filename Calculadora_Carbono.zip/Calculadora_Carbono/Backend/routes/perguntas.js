var express = require('express');
var router = express.Router();
var perguntasController = require('../controllers/perguntasController.js'); //exportar os endpoints da pasta controllers

router.get('/', perguntasController.getAllPerguntas);
router.post('/', perguntasController.postPerguntasByBody);
router.delete('/:id', perguntasController.deletePerguntasById); //configurar a rota do endpoint
router.put('/:id', perguntasController.updatePerguntasById);
router.get('/:id', perguntasController.getPerguntasById);

module.exports = router;