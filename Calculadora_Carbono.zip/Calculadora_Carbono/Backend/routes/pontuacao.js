const express = require('express');
const router = express.Router();
const pontuacaoController = require('../controllers/pontuacaoController');



router.get('/', pontuacaoController.getAllPontuacao);
router.post('/', pontuacaoController.postPontuacao);
router.delete('/:id', pontuacaoController.deletePontuacaoById);
router.put('/:id', pontuacaoController.updatePontuacaoById);
router.get('/:id', pontuacaoController.getPontuacaoById);


module.exports = router;