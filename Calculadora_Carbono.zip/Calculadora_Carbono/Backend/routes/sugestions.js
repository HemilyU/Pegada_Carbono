const express = require('express');
const router = express.Router();
const sugestionRouter = require('../controllers/sugestionController.js'); //exportar os endpoints da pasta controllers

router.get('/', sugestionRouter.getAllSugestion);
router.post('/', sugestionRouter.createSugestion);
router.delete('/:id', sugestionRouter.deleteSugestion); //configurar a rota do endpoint
router.put('/:id', sugestionRouter.updateSugestion);

module.exports = router;
