var express = require('express');
var router = express.Router();
var usersController = require('../controllers/usersController.js')

router.get('/', usersController.getAllUsers);
router.post('/', usersController.postUserByBody);
router.delete('/:id', usersController.deleteUserById); //configurar a rota do endpoint
router.put('/:id', usersController.updateUserById);
router.get('/:id', usersController.getUserById);


function authenticateTokenFromSession(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (token == null) return res.sendStatus(401);
  jwt.verify(token, process.env.TOKEN_SECRET, (err, user) => {
    if (err)
      return req.sendStatus(403);
    req.user = user;
    next();
  });
}


module.exports = router;
