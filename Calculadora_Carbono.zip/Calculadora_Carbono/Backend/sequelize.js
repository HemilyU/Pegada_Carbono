 //TODO Implement all the models and business logic using sequelize
const { Sequelize, DataTypes } = require('sequelize');

const UserDataModel = require('./models/Users');
const respostasModel = require('./models/respostas');
const opcaoperguntasModel = require ('./models/sugestions');
const perguntasModel = require ('./models/perguntas');
const pontuacaoModel = require ('./models/pontuacao');
const sugestionsModel = require ('./models/sugestions')



const sequelize = new Sequelize(process.env.DB_SCHEMA, process.env.DB_USER,process.env.DB_PASS, {
    host: process.env.DB_HOST,
    dialect: 'mysql' //Replace...
})

const User = UserDataModel(sequelize, DataTypes);
const respostas = respostasModel(sequelize,DataTypes);
const opcao_pergunta = opcaoperguntasModel (sequelize,DataTypes);
const pontuacao = pontuacaoModel (sequelize,DataTypes);
const perguntas = perguntasModel (sequelize, DataTypes);
const sugestions = sugestionsModel (sequelize, DataTypes);

 //Define relationships

 User.hasMany(respostas);
 respostas.belongsTo(User);

 perguntas.hasMany(respostas);
 respostas.belongsTo(perguntas);

 respostas.hasMany(pontuacao);
 pontuacao.belongsTo(respostas)


sequelize.authenticate()
    .then(() => {
        console.log("Connection has been established");
    })
    .catch(err => {
        console.error("Unable to connect", err);
    });

  //Introdução do dados em tabelas

/*   User.create({
     email: "andrecassio13@hotmail.com",
     password: "12345"
  });

  perguntas.create({
     texto_perguntas: "Quantos Kilometros faz por dia no seu transporte pessoal ou em outro meio, por dia?"
  });
  perguntas.create({
     texto_perguntas: "Quanta energia elétrica consome em casa por dia?"
  });
  perguntas.create({
     texto_perguntas: "Quanto tempo passa no banho diariamente?"
  });
  perguntas.create({
     texto_perguntas: "Qual a quantidade de lixo que produz diaramente?"
  });
  perguntas.create({
     texto_perguntas: "Quantos alimentos de origem animal consome diariamente?"
  });
// pergunta 1
 respostas.create({
     UserId: 1,
     perguntumId: 1,
     opcao_resposta: "2km"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 1,
     opcao_resposta: "4km"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 1,
     opcao_resposta: "+6km"
 });
// pergunta 2
 respostas.create({
     UserId: 1,
     perguntumId: 2,
     opcao_resposta: "8 kw"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 2,
     opcao_resposta: "12 kw"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 2,
     opcao_resposta: "+16 kw"
 });
 //pergunta 3
 respostas.create({
     UserId: 1,
     perguntumId: 3,
     opcao_resposta: "10 min"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 3,
     opcao_resposta: "30 min"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 3,
     opcao_resposta: "+1hora"
 });
// pergunta 4
 respostas.create({
     UserId: 1,
     perguntumId: 4,
     opcao_resposta: "500g"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 4,
     opcao_resposta: "1Kg"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 4,
     opcao_resposta: "2Kg"
 });
 //pergunta 5
 respostas.create({
     UserId: 1,
     perguntumId: 5,
     opcao_resposta: "Pouco"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 5,
     opcao_resposta: "Mais ou menos"
 });
 respostas.create({
     UserId: 1,
     perguntumId: 5,
     opcao_resposta: "Demasiado"
 });
 */

 sequelize.sync({ force: false})
     .then(() => {
         console.log('Tables Created!');
     });


module.exports = {
    User,perguntas,respostas,pontuacao,opcao_pergunta,sugestions
};
