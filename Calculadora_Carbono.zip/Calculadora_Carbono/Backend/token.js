var crypto = require ('crypto');
var tokenSecret = crypto.randomBytes(64).toString('hex');
console.log (tokenSecret);
//executar node token.js e utilizar a resposta para TOKEN_SECRET