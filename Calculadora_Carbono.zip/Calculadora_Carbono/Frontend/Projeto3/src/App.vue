
<template>
  <div class="app">
    <HeaderNav />
    <RouterView />
    <footermain />
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router'
import HeaderNav from '@/components/header.vue'
import footermain from '@/components/footer.vue'


</script>

