<template>
    <footermain>
        <div class="w-100 vh-50 d-flex flex-column justify-content-between">

            <footer class="text-center text-lg-start  navbar-light" style="background-color:  rgb(36, 174, 238);">
                <div class="container d-flex justify-content-center py-5">
                    <button type="button" class="btn btn-primary btn-lg btn-floating mx-2"
                        style="background-color: #79bef3;">
                        <i class="fab fa-facebook-f"></i>
                    </button>
                    <button type="button" class="btn btn-primary btn-lg btn-floating mx-2"
                        style="background-color:#79bef3;">
                        <i class="fab fa-youtube"></i>
                    </button>
                    <button type="button" class="btn btn-primary btn-lg btn-floating mx-2"
                        style="background-color: #79bef3;">
                        <i class="fab fa-instagram"></i>
                    </button>
                    <button type="button" class="btn btn-primary btn-lg btn-floating mx-2"
                        style="background-color: #79bef3;">
                        <i class="fab fa-twitter"></i>
                    </button>
                </div>

                <div class="text-center text-white p-3" style="background-color: rgba(0, 0, 0, 0.2);">
                    © 2023 Copyright:
                    <a class="text-white" >Projeto 3</a>
                </div>
            </footer>
        </div>
    </footermain>
</template>
<style>
    footermain {
        min-height: 100vh;
    }

    footer {
        flex: 1;
    }
</style>