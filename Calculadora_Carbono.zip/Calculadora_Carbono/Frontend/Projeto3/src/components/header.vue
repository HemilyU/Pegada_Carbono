<template>
  <header>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color:rgb(36, 174, 238);">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">
          <img src="https://tse4.mm.bing.net/th?id=OIP.9HqxLwWbQEi57WsE1FNJewHaE8&pid=Api&P=0&h=180" alt="Logo" width="80" height="60" class="d-inline-block align-text-top">
        </a>
        <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarExample01"
          aria-controls="navbarExample01" aria-expanded="false" aria-label="Toggle navigation">
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarExample01">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0 custom-nav">
            <li class="nav-item active">
              <router-link to="/" class="nav-link">Home</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/pesquisa" class="nav-link">Sugestões</router-link>
            </li>
            <li class="nav-item ms-auto">
              <router-link v-if="!isLoggedIn" to="/login" class="nav-link">Login</router-link>
              <router-link v-else to="/login" @click="logout" class="nav-link">Logout</router-link>
            </li>
            <li class="nav-item">
              <router-link to="/registro" class="nav-link">Registo</router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
</template>

<script>
export default {
  data() {
    return {
      isLoggedIn: false, // Variable para verificar si el usuario ha iniciado sesión
    };
  },
  created() {
    this.isLoggedIn = this.checkIfUserIsLoggedIn(); // Reemplaza "checkIfUserIsLoggedIn" con tu propia lógica de verificación
  },
  methods: {
    checkIfUserIsLoggedIn() {
      // Implementa tu lógica de verificación de inicio de sesión aquí
      // Puedes usar localStorage, cookies o cualquier otro método de autenticación
      return localStorage.getItem('jwt') !== null;
    },
    logout() {
      // Realiza la lógica de cierre de sesión aquí, como eliminar el token de autenticación
      localStorage.removeItem('jwt');
      this.isLoggedIn = false; // Establece la variable isLoggedIn en falso
      // Realiza cualquier redirección u otra lógica necesaria después del cierre de sesión
      this.$router.push('/login');
    },
  },
};
</script>
