import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/home.vue'
import login from '../views/login.vue'
import registro from '../views/signup.vue'
import pesquisa from '../views/pesquisa.vue'
import pregunta_1 from '../views/pregunta_1.vue'
import pregunta_2 from '../views/pregunta_2.vue'
import pregunta_3 from '../views/pregunta_3.vue'
import pregunta_4 from '../views/pregunta_4.vue'
import pregunta_5 from '../views/pregunta_5.vue'
import resultado from '../views/resultado.vue'
import Unauthorized from '../views/Unauthorized.vue'



const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
      meta: { requiresAuth: true}
    },
    {
      path: '/login',
      name: 'login',
      component: login
     
    },
    {
      path: '/registro',
      name: 'registro',
      component: registro
     
    },
    {
      path: '/pesquisa',
      name: 'pesquisa',
      component: pesquisa,
      meta: { requiresAuth: true}

     
    },
    {
      path: '/pregunta_1',
      name: 'pregunta_1',
      component: pregunta_1
     
    },
    {
      path: '/pregunta_2',
      name: 'pregunta_2',
      component: pregunta_2
     
    },
    {
      path: '/pregunta_3',
      name: 'pregunta_3',
      component: pregunta_3
     
    },
    {
      path: '/pregunta_4',
      name: 'pregunta_4',
      component: pregunta_4
     
    },
    {
      path: '/pregunta_5',
      name: 'pregunta_5',
      component: pregunta_5
     
    },
   
    {
      path: '/resultado',
      name: 'resultado',
      component: resultado
     
    },
    {
      path: '/Unauthorized',
      name: 'Unauthorized',
      component: Unauthorized 
    }

  ]
})
router.beforeEach((to, from, next) => {
  const isAuthenticated = localStorage.getItem('jwt');
  const requiresAuth = to.matched.some((route) => route.meta.requiresAuth);

  if (requiresAuth && !isAuthenticated) {
    next('/login'); // Redirige a la página de inicio de sesión
  } else if ((to.name === 'login' || to.name === 'signup') && isAuthenticated) {
    next('/'); // Redirige a la página de inicio si el usuario ya está autenticado
  } else {
    next(); // Permite la navegación
  }
});

export default router
