<template>
    <div id="intro-example" class="p-5 text-center bg-image" style="background-image: url('https://medicinagaditana.es/wp-content/uploads/2019/06/medio-ambiente-1024x679.jpg'); background-size: cover; background-position: center; height: 80vh;">
      <div class="mask">
        <div class="d-flex justify-content-center align-items-center h-100">
          <div class="text-white">
            <h1 class="mb-3">Bem-vindo(a) </h1>
            <h5 class="mb-4">Pense no futuro</h5>
            <a class="btn btn-outline-light btn-lg m-2" href= "/resultado">Start questionary</a>
          </div>
        </div>
      </div>
    </div>
    
</template>
<script>
</script>