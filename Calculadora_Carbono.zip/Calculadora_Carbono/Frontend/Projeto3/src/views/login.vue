<template>
  <section class="vh-60">
    <div class="container-fluid h-custom">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-md-9 col-lg-6 col-xl-5">
          <img
            src="https://img.freepik.com/vector-premium/proteccion-ecologica-cuidado-medio-ambiente-natural_24640-20163.jpg?w=740"
            class="img-fluid" alt="Sample image">
        </div>
        <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
          <form @submit.prevent="loginUser">


            <!-- Email input -->
            <div class="d-flex flex-row align-items-center mb-4">
              <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
              <input type="email" name="email" id="form3Example3" class="form-control form-control-lg"
                placeholder="Enter a valid email address" />
              <label class="form-label" for="form3Example3">Email</label>
            </div>

            <!-- Password input -->
            <div class="d-flex flex-row align-items-center mb-4">
              <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
              <input type="password" name="password" id="form3Example4" class="form-control form-control-lg"
                placeholder="Enter password" />
              <label class="form-label" for="form3Example4">Password</label>
            </div>

            <div class="d-flex justify-content-between align-items-center">
              <!-- Checkbox -->
              <div class="form-check mb-0">
                <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3" />
                <label class="form-check-label" for="form2Example3">
                  Remember me
                </label>
              </div>
              <a href="#!" class="text-body">Forgot password?</a>
            </div>

            <div class="text-center text-lg-start mt-4 pt-2">
              <button type="submit" class="btn btn-success btn-lg"
                style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button>
              <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="/registro"
                  class="link-danger">Register</a></p>
            </div>
            <button v-if="isLoggedIn" @click="logout">Logout</button>
          </form>
        </div>
      </div>
    </div>

  </section>
</template>
<script>
import axios from "axios";
import { useRouter } from "vue-router";

const router = useRouter()

export default {
  data() {
    return {
      isLoggedIn: false, // Variable para verificar si el usuario ha iniciado sesión
    };
  },
  methods: {
    loginUser(e) {
      e.preventDefault(); // Evita que el formulario se envíe de forma predeterminada

      let email = e.target.elements.email.value;
      let password = e.target.elements.password.value;
      let data = {
        email,
        password
      };

      // Realiza la petición al servidor para iniciar sesión
      axios.post("http://localhost:3000/login", data)
        .then(res => {
          console.log(res);
          localStorage.setItem("jwt", res.data.token);
          this.isLoggedIn = true; // Establece la variable isLoggedIn en true
          // Realiza cualquier redirección u otra lógica necesaria después del inicio de sesión exitoso
          this.$router.push("/");
          
        })
        .catch((error => {
          console.error(error) ;
          console.log(error);
          this.$router.push({
            name: "unauthorized",
            params: {
              message: error.response.data.message,
            },
          });
        }));
      }
    }
    }
</script>
