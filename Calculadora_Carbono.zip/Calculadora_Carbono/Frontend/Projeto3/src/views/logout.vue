<template>
    <div>
      <!-- Resto de tu contenido -->
      <button v-if="isLoggedIn" @click="logout">Logout</button>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        isLoggedIn: false, // Variable para verificar si el usuario ha iniciado sesión
      };
    },
    methods: {
    
      logout() {
      // Lógica para hacer logout
      localStorage.removeItem("jwt");
      this.isLoggedIn = false; // Establece la variable isLoggedIn en false
      // Realiza cualquier redirección u otra lógica necesaria después de cerrar la sesión
      this.$router.push("/login");
    }
    },
  };
  </script>