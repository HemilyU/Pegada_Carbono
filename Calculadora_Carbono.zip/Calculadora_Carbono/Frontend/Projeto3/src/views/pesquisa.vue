<template>
  <div class="card-container">
    <div class="card" style="width: 20rem; height: 20rem;">
      <img src="https://tse1.mm.bing.net/th?id=OIP.LPc8x9nIJam0-njjHDLYRgHaE8&pid=Api&P=0&h=180" class="card-img-top"
        alt="...">
      <div class="card-body">
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
          content.</p>
      </div>
    </div>
    <div class="card" style="width: 20rem; height: 20rem;">
      <img src="https://tse4.mm.bing.net/th?id=OIP.0_TzgWmJcSOy8xhZffaKkAHaD4&pid=Api&P=0&h=180" class="card-img-top"
        alt="...">
      <div class="card-body">
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
          content.</p>
      </div>
    </div>
    <div class="card" style="width: 20rem; height: 20rem;">
      <img src="https://tse4.mm.bing.net/th?id=OIP.Yu1wt-ofwm9Vm6_RgRw0ZwHaEc&pid=Api&P=0&h=180" class="card-img-top"
        alt="...">
      <div class="card-body">
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
          content.</p>
      </div>
    </div>
    <div class="card" style="width: 20rem; height: 20rem;">
      <img src="https://tse3.mm.bing.net/th?id=OIP.QRH4DdMt9M1rNZqK0VKQGwHaEY&pid=Api&P=0&h=180" class="card-img-top"
        alt="...">
      <div class="card-body">
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
          content.</p>
      </div>
    </div>
    <div class="card" style="width: 20rem; height: 20rem;">
      <img src="https://tse1.mm.bing.net/th?id=OIP.wNTwhfj-1WxPCPuEFxDk5AHaEK&pid=Api&P=0&h=180" class="card-img-top"
        alt="...">
      <div class="card-body">
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
          content.</p>
      </div>
    </div>
    <div class="card" style="width: 20rem; height: 20rem;">
      <img src="https://tse3.mm.bing.net/th?id=OIP.m6frmh9t6G3EzBDYWmnOLwEsCd&pid=Api&P=0&h=180" class="card-img-top"
        alt="...">
      <div class="card-body">
        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
          content.</p>
      </div>
    </div>
    <input type="text" v-model="novaSugestao" placeholder="Digite uma nova sugestão" />
    <button type="button" @click="enviarSugestao">Enviar Sugestão</button>  </div>
</template>
<script>
import axios from 'axios';

export default {
  data() {
    return {
      texto: '', // Inicialize a propriedade de dados "texto"
      novaSugestao: '',
    };
  },
  methods: {

    enviarSugestao() {
      const sugestao = {
        texto: this.novaSugestao,
      };
      axios
        .post('http://localhost:3000/sugestions', sugestao) // Use this.texto para obter o valor da propriedade de dados
        .then(response => {
          // A sugestão foi enviada com sucesso, faça qualquer tratamento necessário
          console.log('Sugestão enviada:', response.data);
          // Limpe o campo de entrada
          this.novaSugestao = '';
        })
        .catch(error => {
          console.error('Erro ao enviar a sugestão: ', error);
        });
    }
  },
};
</script>