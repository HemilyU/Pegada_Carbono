<template>

    <div id="intro-example" class="p-5 text-center bg-image" style="background-image: url('https://medicinagaditana.es/wp-content/uploads/2019/06/medio-ambiente-1024x679.jpg'); background-size: cover; background-position: center; height: 70vh;">
      <div class="mask">
        <div class="d-flex justify-content-center align-items-center h-100">
          <div class="text-black">
            <h1 class="mb-3">Bem-vindo(a) </h1>
            <h5 class="mb-4">Pense no futuro</h5>
            <div class="mx-0 w-100">
              <div class="text-center mb-3">
                <p>
                  <strong style="margin-top: 30px;">Qual a quantidade de lixo que produz diaramente? </strong>
                </p>
              </div>
              <div class="container_pregunta ">
                <label for="customRange3" class="form-label corner-top-left">500 g</label>
                <label for="customRange3" class="form-label middle">1 kg</label>
                <label for="customRange3" class="form-label corner-top-right">+2 kg</label>
                <input type="range" class="form-range" id="customRange3" min="0" max="2" step="1" v-model="respuesta">
                <div class="porcentaje">{{ respuesta * 50 }}%</div>
              </div>
              <div class="text-end">
                <button type="button" class="btn btn-primary mt-3" @click="submit">Submit</button>
                <div class="arrow-container left">
                  <a href="/pregunta_3" class="arrow">&#8592;</a>
                </div>
  
                <div class="arrow-container right">
                  <a href="/pregunta_5" class="arrow">&#8594;</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        respuesta: 0, // Variable para almacenar la respuesta del usuario
      };
    },
    methods: {
      submit() {
        this.$emit("respuesta", this.respuesta);
      },
    },
  };
  </script>