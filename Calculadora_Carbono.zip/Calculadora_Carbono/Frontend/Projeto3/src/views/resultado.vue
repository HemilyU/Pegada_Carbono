<template>
  <div>
    <Pregunta1 @respuesta="guardarRespuesta(0, $event)"></Pregunta1>
    <Pregunta2 @respuesta="guardarRespuesta(1, $event)"></Pregunta2>
    <Pregunta3 @respuesta="guardarRespuesta(2, $event)"></Pregunta3>
    <Pregunta4 @respuesta="guardarRespuesta(3, $event)"></Pregunta4>
    <Pregunta5 @respuesta="guardarRespuesta(4, $event)"></Pregunta5>

    <!-- Botón para calcular la huella de carbono -->
    <button type="submit" @click="enviarDatos">Calcular huella de carbono</button>

    <!-- Mostrar la huella de carbono -->
    <div v-if="huellaCarbono !== null">
      Huella de carbono: {{ huellaCarbono }}
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Pregunta1 from "@/views/pregunta_1.vue";
import Pregunta2 from "@/views/pregunta_2.vue";
import Pregunta3 from "@/views/pregunta_3.vue";
import Pregunta4 from "@/views/pregunta_4.vue";
import Pregunta5 from "@/views/pregunta_5.vue";

export default {
  components: {
    Pregunta1,
    Pregunta2,
    Pregunta3,
    Pregunta4,
    Pregunta5,
  },
  data() {
    return {
      respuestas: [], // Arreglo para almacenar las respuestas
      huellaCarbono: null,
    };
  },
  methods: {
    guardarRespuesta(index, respuesta) {
      this.respuestas[index] = respuesta;
    },
    async enviarDatos() {
      // Realizar una solicitud POST al backend


      let currentToken = localStorage.getItem("jwt")

      // let data={             headers: {
      //         Authorization: "Bearer " + currentToken
      //       },
      //   pontuacao_respostas: '65'
      //  }
      let pontuacao_respostas = {pontuacao_respostas: this.respuestas}
      let headers = {
         headers: {
          Authorization: "Bearer " + currentToken
         }
      }
      //token: currentToken
      await axios
        .post('http://localhost:3000/pontuacaos', pontuacao_respostas, headers)
        .then(response => {
          // Obtener la respuesta del backend y actualizar la variable huellaCarbono
          console.log(response.data.huellaCarbono);
          this.huellaCarbono = response.data.huellaCarbono;
        })
        .catch(error => {
          console.error("Ocurrió un error al enviar los datos al backend:", error);
        });
    },
  },
};
</script>