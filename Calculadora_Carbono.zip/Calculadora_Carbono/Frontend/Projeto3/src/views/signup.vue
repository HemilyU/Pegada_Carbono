
<template>
    <section class="vh-60">
      <div class="container-fluid h-custom">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col-md-9 col-lg-6 col-xl-5 d-flex align-items-center order-1 order-lg-2">
            <img src="https://img.freepik.com/vector-premium/proteccion-ecologica-cuidado-medio-ambiente-natural_24640-20163.jpg?w=740" class="img-fluid" alt="Sample image">
          </div>
          <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
            <form @submit.prevent="registerUser" class="mx-1 mx-md-4">
              <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Sign up</p>
              <!-- Email input -->
              <div class="d-flex flex-row align-items-center mb-4">
                <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                <input type="email" name="email" id="form3Example3" class="form-control form-control-lg" placeholder="Enter a valid email address" v-model="email" />
                <label class="form-label" for="form3Example3"></label>
              </div>
              <!-- Password input -->
              <div class="d-flex flex-row align-items-center mb-4">
                <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                <input type="password" name="password" id="form3Example4" class="form-control form-control-lg" placeholder="Enter password" v-model="password" />
                <label class="form-label" for="form3Example4"></label>
              </div>
              <div class="text-center text-lg-start mt-4 pt-2">
                <button type="submit" class="btn btn-success btn-lg" style="padding-left: 2.5rem; padding-right: 2.5rem;">Registro</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </template>
  
  <script>
  import axios from "axios"
  import { useRoute } from "vue-router"
  
  const route = useRoute()
  
  export default {
    data() {
      return {
        email: "", // Variável para armazenar o email do formulário
        password: "", // Variável para armazenar a senha do formulário
      };
    },
    methods: {
      registerUser() {
        let data = {
          email: this.email,
          password: this.password
        }
        axios.post("http://localhost:3000/signup", data)
          .then(res => {
            console.log(res)
            localStorage.setItem("jwt", res.data.token)
            this.$router.push("/");
          })
          .catch(error => {
            console.error(error);
            console.log(error.response.status); // Código de status HTTP retornado pelo servidor
            console.log(error.response.data); // Mensagem de erro retornada pelo servidor
          });
      },
    }
  };
  </script>
 
  
  
  
  
  
  
  